create
	procedure [cdc].[sp_insdel_50099219]
	(	@__$start_lsn binary(10),
		@__$seqval binary(10),
		@__$operation int,
		@__$update_mask varbinary(128) , @c6 int, @c7 nvarchar(100), @c8 datetime, @c9 datetime, @c10 nvarchar(100), @c11 decimal(10,2), @c12 nvarchar(100), @c13 nvarchar(100), @c14 nvarchar(100), @c15 int, @c16 nvarchar(100), @c17 int, @c18 int, @c19 int, @c20 nvarchar(100), @c21 nvarchar(100), @c22 nvarchar(100), @c23 nvarchar(100), @c24 int, @c25 nvarchar(100), @c26 nvarchar(100), @c27 nvarchar(100), @c28 nvarchar(100), @c29 nvarchar(100), @c30 nvarchar(100), @c31 nvarchar(100), @c32 nvarchar(100), @c33 datetime, @c34 datetime, @c35 int, @c36 decimal(10,2), @c37 nvarchar(max), @c38 nvarchar(100), @c39 nvarchar(100), @c40 int, @c41 int, @c42 nvarchar(100), @c43 nvarchar(100), @c44 nvarchar(100), @c45 nvarchar(100), @c46 nvarchar(100), @c47 nvarchar(100), @c48 nvarchar(100), @c49 nvarchar(100), @c50 nvarchar(100), @c51 nvarchar(100), @c52 datetime, @c53 datetime, @c54 int, @c55 datetime, @c56 int, @c57 decimal(10,2), @c58 nvarchar(100), @c59 decimal(10,2), @c60 nvarchar(100), @c61 nvarchar(100),
		@__$command_id int = null
	)
	as
	begin
		insert into [cdc].[dbo_GUEST_TRANSACTION_CT] 
		(
			__$start_lsn
			,__$end_lsn
			,__$seqval
			,__$operation
			,__$update_mask , [Id], [TransactionType], [CheckInDate], [CheckOutDate], [Nights], [TotalAmount], [RoomType], [Children], [Adults], [RoomRate], [VisitReview], [MinibarUsage], [RoomCharge], [RoomServiceAmount], [TVUsageStatistics], [Complain], [UsedAmenities], [ReservationSource], [Package], [UsageWhatsappConcierge], [BreakfastIncluded], [HotelName], [HotelLocatoin], [VisitPurpose], [DiscountType], [Venue], [Location], [VisitDate], [VisitTime], [NumberOfGuests], [AverageAmount], [OrderDetails], [PaymentType], [Source], [IsHotelGuest], [VisitNumber], [TableType], [ServiceType], [EventName], [EventType], [FavoriteProcedure], [FavoriteSpecialist], [FavoriteCategory], [ExtraProducts], [Membership], [CreatedBy], [CreatedOn], [UpdatedOn], [IsProcessed], [ProcessDate], [ItemId], [WeatherTemperature], [HotelPackage], [ExchangeRateUSD], [OperatorDetails], [PaymentMethod]
			,__$command_id
		)
		values
		(
			@__$start_lsn
			,NULL
			,@__$seqval
			,@__$operation
			,@__$update_mask , @c6, @c7, @c8, @c9, @c10, @c11, @c12, @c13, @c14, @c15, @c16, @c17, @c18, @c19, @c20, @c21, @c22, @c23, @c24, @c25, @c26, @c27, @c28, @c29, @c30, @c31, @c32, @c33, @c34, @c35, @c36, @c37, @c38, @c39, @c40, @c41, @c42, @c43, @c44, @c45, @c46, @c47, @c48, @c49, @c50, @c51, @c52, @c53, @c54, @c55, @c56, @c57, @c58, @c59, @c60, @c61
			,@__$command_id
		)
		return 0
	end
go

