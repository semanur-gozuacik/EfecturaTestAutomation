create
	procedure [cdc].[sp_upd_50099219]
	(	@__$start_lsn binary(10),
		@__$seqval binary(10),
		@__$update_mask varbinary(128) , @c6_old int, @c7_old nvarchar(100), @c8_old datetime, @c9_old datetime, @c10_old nvarchar(100), @c11_old decimal(10,2), @c12_old nvarchar(100), @c13_old nvarchar(100), @c14_old nvarchar(100), @c15_old int, @c16_old nvarchar(100), @c17_old int, @c18_old int, @c19_old int, @c20_old nvarchar(100), @c21_old nvarchar(100), @c22_old nvarchar(100), @c23_old nvarchar(100), @c24_old int, @c25_old nvarchar(100), @c26_old nvarchar(100), @c27_old nvarchar(100), @c28_old nvarchar(100), @c29_old nvarchar(100), @c30_old nvarchar(100), @c31_old nvarchar(100), @c32_old nvarchar(100), @c33_old datetime, @c34_old datetime, @c35_old int, @c36_old decimal(10,2), @c37_old nvarchar(max), @c38_old nvarchar(100), @c39_old nvarchar(100), @c40_old int, @c41_old int, @c42_old nvarchar(100), @c43_old nvarchar(100), @c44_old nvarchar(100), @c45_old nvarchar(100), @c46_old nvarchar(100), @c47_old nvarchar(100), @c48_old nvarchar(100), @c49_old nvarchar(100), @c50_old nvarchar(100), @c51_old nvarchar(100), @c52_old datetime, @c53_old datetime, @c54_old int, @c55_old datetime, @c56_old int, @c57_old decimal(10,2), @c58_old nvarchar(100), @c59_old decimal(10,2), @c60_old nvarchar(100), @c61_old nvarchar(100), @c6_new int, @c7_new nvarchar(100), @c8_new datetime, @c9_new datetime, @c10_new nvarchar(100), @c11_new decimal(10,2), @c12_new nvarchar(100), @c13_new nvarchar(100), @c14_new nvarchar(100), @c15_new int, @c16_new nvarchar(100), @c17_new int, @c18_new int, @c19_new int, @c20_new nvarchar(100), @c21_new nvarchar(100), @c22_new nvarchar(100), @c23_new nvarchar(100), @c24_new int, @c25_new nvarchar(100), @c26_new nvarchar(100), @c27_new nvarchar(100), @c28_new nvarchar(100), @c29_new nvarchar(100), @c30_new nvarchar(100), @c31_new nvarchar(100), @c32_new nvarchar(100), @c33_new datetime, @c34_new datetime, @c35_new int, @c36_new decimal(10,2), @c37_new nvarchar(max), @c38_new nvarchar(100), @c39_new nvarchar(100), @c40_new int, @c41_new int, @c42_new nvarchar(100), @c43_new nvarchar(100), @c44_new nvarchar(100), @c45_new nvarchar(100), @c46_new nvarchar(100), @c47_new nvarchar(100), @c48_new nvarchar(100), @c49_new nvarchar(100), @c50_new nvarchar(100), @c51_new nvarchar(100), @c52_new datetime, @c53_new datetime, @c54_new int, @c55_new datetime, @c56_new int, @c57_new decimal(10,2), @c58_new nvarchar(100), @c59_new decimal(10,2), @c60_new nvarchar(100), @c61_new nvarchar(100),
		@__$command_id int = null
	)
	as
	begin
		insert into [cdc].[dbo_GUEST_TRANSACTION_CT] 
		(
			__$start_lsn
			,__$end_lsn
			,__$seqval
			,__$operation
			,__$update_mask , [Id], [TransactionType], [CheckInDate], [CheckOutDate], [Nights], [TotalAmount], [RoomType], [Children], [Adults], [RoomRate], [VisitReview], [MinibarUsage], [RoomCharge], [RoomServiceAmount], [TVUsageStatistics], [Complain], [UsedAmenities], [ReservationSource], [Package], [UsageWhatsappConcierge], [BreakfastIncluded], [HotelName], [HotelLocatoin], [VisitPurpose], [DiscountType], [Venue], [Location], [VisitDate], [VisitTime], [NumberOfGuests], [AverageAmount], [OrderDetails], [PaymentType], [Source], [IsHotelGuest], [VisitNumber], [TableType], [ServiceType], [EventName], [EventType], [FavoriteProcedure], [FavoriteSpecialist], [FavoriteCategory], [ExtraProducts], [Membership], [CreatedBy], [CreatedOn], [UpdatedOn], [IsProcessed], [ProcessDate], [ItemId], [WeatherTemperature], [HotelPackage], [ExchangeRateUSD], [OperatorDetails], [PaymentMethod]
			,__$command_id
		)
		values
		(
			@__$start_lsn
			,NULL
			,@__$seqval
			,3
			,@__$update_mask , @c6_old, @c7_old, @c8_old, @c9_old, @c10_old, @c11_old, @c12_old, @c13_old, @c14_old, @c15_old, @c16_old, @c17_old, @c18_old, @c19_old, @c20_old, @c21_old, @c22_old, @c23_old, @c24_old, @c25_old, @c26_old, @c27_old, @c28_old, @c29_old, @c30_old, @c31_old, @c32_old, @c33_old, @c34_old, @c35_old, @c36_old, @c37_old, @c38_old, @c39_old, @c40_old, @c41_old, @c42_old, @c43_old, @c44_old, @c45_old, @c46_old, @c47_old, @c48_old, @c49_old, @c50_old, @c51_old, @c52_old, @c53_old, @c54_old, @c55_old, @c56_old, @c57_old, @c58_old, @c59_old, @c60_old, @c61_old
			,@__$command_id
		)
		
		insert into [cdc].[dbo_GUEST_TRANSACTION_CT] 
		(
			__$start_lsn
			,__$end_lsn
			,__$seqval
			,__$operation
			,__$update_mask , [Id], [TransactionType], [CheckInDate], [CheckOutDate], [Nights], [TotalAmount], [RoomType], [Children], [Adults], [RoomRate], [VisitReview], [MinibarUsage], [RoomCharge], [RoomServiceAmount], [TVUsageStatistics], [Complain], [UsedAmenities], [ReservationSource], [Package], [UsageWhatsappConcierge], [BreakfastIncluded], [HotelName], [HotelLocatoin], [VisitPurpose], [DiscountType], [Venue], [Location], [VisitDate], [VisitTime], [NumberOfGuests], [AverageAmount], [OrderDetails], [PaymentType], [Source], [IsHotelGuest], [VisitNumber], [TableType], [ServiceType], [EventName], [EventType], [FavoriteProcedure], [FavoriteSpecialist], [FavoriteCategory], [ExtraProducts], [Membership], [CreatedBy], [CreatedOn], [UpdatedOn], [IsProcessed], [ProcessDate], [ItemId], [WeatherTemperature], [HotelPackage], [ExchangeRateUSD], [OperatorDetails], [PaymentMethod]
			,__$command_id
		)
		values
		(
			@__$start_lsn
			,NULL
			,@__$seqval
			,4
			,@__$update_mask , @c6_new, @c7_new, @c8_new, @c9_new, @c10_new, @c11_new, @c12_new, @c13_new, @c14_new, @c15_new, @c16_new, @c17_new, @c18_new, @c19_new, @c20_new, @c21_new, @c22_new, @c23_new, @c24_new, @c25_new, @c26_new, @c27_new, @c28_new, @c29_new, @c30_new, @c31_new, @c32_new, @c33_new, @c34_new, @c35_new, @c36_new, @c37_new, @c38_new, @c39_new, @c40_new, @c41_new, @c42_new, @c43_new, @c44_new, @c45_new, @c46_new, @c47_new, @c48_new, @c49_new, @c50_new, @c51_new, @c52_new, @c53_new, @c54_new, @c55_new, @c56_new, @c57_new, @c58_new, @c59_new, @c60_new, @c61_new
			,@__$command_id
		)
		
		return 0
	end
go

