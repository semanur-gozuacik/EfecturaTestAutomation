
	create function [cdc].[fn_cdc_get_net_changes_dbo_GUEST_TRANSACTION]
	(	@from_lsn binary(10),
		@to_lsn binary(10),
		@row_filter_option nvarchar(30)
	)
	returns table
	return

	select NULL as __$start_lsn,
		NULL as __$operation,
		NULL as __$update_mask, NULL as [Id], NULL as [TransactionType], NULL as [CheckInDate], NULL as [CheckOutDate], NULL as [Nights], NULL as [TotalAmount], NULL as [RoomType], NULL as [Children], NULL as [Adults], NULL as [RoomRate], NULL as [VisitReview], NULL as [MinibarUsage], NULL as [RoomCharge], NULL as [RoomServiceAmount], NULL as [TVUsageStatistics], NULL as [Complain], NULL as [UsedAmenities], NULL as [ReservationSource], NULL as [Package], NULL as [UsageWhatsappConcierge], NULL as [BreakfastIncluded], NULL as [HotelName], NULL as [HotelLocatoin], NULL as [VisitPurpose], NULL as [DiscountType], NULL as [Venue], NULL as [Location], NULL as [VisitDate], NULL as [VisitTime], NULL as [NumberOfGuests], NULL as [AverageAmount], NULL as [OrderDetails], NULL as [PaymentType], NULL as [Source], NULL as [IsHotelGuest], NULL as [VisitNumber], NULL as [TableType], NULL as [ServiceType], NULL as [EventName], NULL as [EventType], NULL as [FavoriteProcedure], NULL as [FavoriteSpecialist], NULL as [FavoriteCategory], NULL as [ExtraProducts], NULL as [Membership], NULL as [CreatedBy], NULL as [CreatedOn], NULL as [UpdatedOn], NULL as [IsProcessed], NULL as [ProcessDate], NULL as [ItemId], NULL as [WeatherTemperature], NULL as [HotelPackage], NULL as [ExchangeRateUSD], NULL as [OperatorDetails], NULL as [PaymentMethod]
	where ( [sys].[fn_cdc_check_parameters]( N'dbo_GUEST_TRANSACTION', @from_lsn, @to_lsn, lower(rtrim(ltrim(@row_filter_option))), 1) = 0)

	union all
	
	select __$start_lsn,
	    case __$count_2289239F
	    when 1 then __$operation
	    else
			case __$min_op_2289239F 
				when 2 then 2
				when 4 then
				case __$operation
					when 1 then 1
					else 4
					end
				else
				case __$operation
					when 2 then 4
					when 4 then 4
					else 1
					end
			end
		end as __$operation,
		null as __$update_mask , [Id], [TransactionType], [CheckInDate], [CheckOutDate], [Nights], [TotalAmount], [RoomType], [Children], [Adults], [RoomRate], [VisitReview], [MinibarUsage], [RoomCharge], [RoomServiceAmount], [TVUsageStatistics], [Complain], [UsedAmenities], [ReservationSource], [Package], [UsageWhatsappConcierge], [BreakfastIncluded], [HotelName], [HotelLocatoin], [VisitPurpose], [DiscountType], [Venue], [Location], [VisitDate], [VisitTime], [NumberOfGuests], [AverageAmount], [OrderDetails], [PaymentType], [Source], [IsHotelGuest], [VisitNumber], [TableType], [ServiceType], [EventName], [EventType], [FavoriteProcedure], [FavoriteSpecialist], [FavoriteCategory], [ExtraProducts], [Membership], [CreatedBy], [CreatedOn], [UpdatedOn], [IsProcessed], [ProcessDate], [ItemId], [WeatherTemperature], [HotelPackage], [ExchangeRateUSD], [OperatorDetails], [PaymentMethod]
	from
	(
		select t.__$start_lsn as __$start_lsn, __$operation,
		case __$count_2289239F 
		when 1 then __$operation 
		else
		(	select top 1 c.__$operation
			from [cdc].[dbo_GUEST_TRANSACTION_CT] c with (nolock)   
			where  ( (c.[Id] = t.[Id]) )  
			and ((c.__$operation = 2) or (c.__$operation = 4) or (c.__$operation = 1))
			and (c.__$start_lsn <= @to_lsn)
			and (c.__$start_lsn >= @from_lsn)
			order by c.__$start_lsn, c.__$command_id, c.__$seqval) end __$min_op_2289239F, __$count_2289239F, t.[Id], t.[TransactionType], t.[CheckInDate], t.[CheckOutDate], t.[Nights], t.[TotalAmount], t.[RoomType], t.[Children], t.[Adults], t.[RoomRate], t.[VisitReview], t.[MinibarUsage], t.[RoomCharge], t.[RoomServiceAmount], t.[TVUsageStatistics], t.[Complain], t.[UsedAmenities], t.[ReservationSource], t.[Package], t.[UsageWhatsappConcierge], t.[BreakfastIncluded], t.[HotelName], t.[HotelLocatoin], t.[VisitPurpose], t.[DiscountType], t.[Venue], t.[Location], t.[VisitDate], t.[VisitTime], t.[NumberOfGuests], t.[AverageAmount], t.[OrderDetails], t.[PaymentType], t.[Source], t.[IsHotelGuest], t.[VisitNumber], t.[TableType], t.[ServiceType], t.[EventName], t.[EventType], t.[FavoriteProcedure], t.[FavoriteSpecialist], t.[FavoriteCategory], t.[ExtraProducts], t.[Membership], t.[CreatedBy], t.[CreatedOn], t.[UpdatedOn], t.[IsProcessed], t.[ProcessDate], t.[ItemId], t.[WeatherTemperature], t.[HotelPackage], t.[ExchangeRateUSD], t.[OperatorDetails], t.[PaymentMethod] 
		from [cdc].[dbo_GUEST_TRANSACTION_CT] t with (nolock) inner join 
		(	select  r.[Id],
		    count(*) as __$count_2289239F 
			from [cdc].[dbo_GUEST_TRANSACTION_CT] r with (nolock)
			where  (r.__$start_lsn <= @to_lsn)
			and (r.__$start_lsn >= @from_lsn)
			group by   r.[Id]) m
		on t.__$seqval = ( select top 1 c.__$seqval from [cdc].[dbo_GUEST_TRANSACTION_CT] c with (nolock) where  ( (c.[Id] = t.[Id]) )  and c.__$start_lsn <= @to_lsn and c.__$start_lsn >= @from_lsn order by c.__$start_lsn desc, c.__$command_id desc, c.__$seqval desc ) and
		    ( (t.[Id] = m.[Id]) ) 	
		where lower(rtrim(ltrim(@row_filter_option))) = N'all'
			and ( [sys].[fn_cdc_check_parameters]( N'dbo_GUEST_TRANSACTION', @from_lsn, @to_lsn, lower(rtrim(ltrim(@row_filter_option))), 1) = 1)
			and (t.__$start_lsn <= @to_lsn)
			and (t.__$start_lsn >= @from_lsn)
			and ((t.__$operation = 2) or (t.__$operation = 4) or 
				 ((t.__$operation = 1) and
				  (2 not in 
				 		(	select top 1 c.__$operation
							from [cdc].[dbo_GUEST_TRANSACTION_CT] c with (nolock) 
							where  ( (c.[Id] = t.[Id]) )  
							and ((c.__$operation = 2) or (c.__$operation = 4) or (c.__$operation = 1))
							and (c.__$start_lsn <= @to_lsn)
							and (c.__$start_lsn >= @from_lsn)
							order by c.__$start_lsn, c.__$command_id, c.__$seqval
						 ) 
	 			   )
	 			 )
	 			) 
			and t.__$operation = (
				select
					max(mo.__$operation)
				from
					[cdc].[dbo_GUEST_TRANSACTION_CT] as mo with (nolock)
				where
					mo.__$seqval = t.__$seqval
					and 
					 ( (t.[Id] = mo.[Id]) ) 
				group by
					mo.__$seqval
			)	
	) Q
	
	union all
	
	select __$start_lsn,
	    case __$count_2289239F
	    when 1 then __$operation
	    else
			case __$min_op_2289239F 
				when 2 then 2
				when 4 then
				case __$operation
					when 1 then 1
					else 4
					end
				else
				case __$operation
					when 2 then 4
					when 4 then 4
					else 1
					end
			end
		end as __$operation,
		case __$count_2289239F
		when 1 then
			case __$operation
			when 4 then __$update_mask
			else null
			end
		else	
			case __$min_op_2289239F 
			when 2 then null
			else
				case __$operation
				when 1 then null
				else __$update_mask 
				end
			end	
		end as __$update_mask , [Id], [TransactionType], [CheckInDate], [CheckOutDate], [Nights], [TotalAmount], [RoomType], [Children], [Adults], [RoomRate], [VisitReview], [MinibarUsage], [RoomCharge], [RoomServiceAmount], [TVUsageStatistics], [Complain], [UsedAmenities], [ReservationSource], [Package], [UsageWhatsappConcierge], [BreakfastIncluded], [HotelName], [HotelLocatoin], [VisitPurpose], [DiscountType], [Venue], [Location], [VisitDate], [VisitTime], [NumberOfGuests], [AverageAmount], [OrderDetails], [PaymentType], [Source], [IsHotelGuest], [VisitNumber], [TableType], [ServiceType], [EventName], [EventType], [FavoriteProcedure], [FavoriteSpecialist], [FavoriteCategory], [ExtraProducts], [Membership], [CreatedBy], [CreatedOn], [UpdatedOn], [IsProcessed], [ProcessDate], [ItemId], [WeatherTemperature], [HotelPackage], [ExchangeRateUSD], [OperatorDetails], [PaymentMethod]
	from
	(
		select t.__$start_lsn as __$start_lsn, __$operation,
		case __$count_2289239F 
		when 1 then __$operation 
		else
		(	select top 1 c.__$operation
			from [cdc].[dbo_GUEST_TRANSACTION_CT] c with (nolock)
			where  ( (c.[Id] = t.[Id]) )  
			and ((c.__$operation = 2) or (c.__$operation = 4) or (c.__$operation = 1))
			and (c.__$start_lsn <= @to_lsn)
			and (c.__$start_lsn >= @from_lsn)
			order by c.__$start_lsn, c.__$command_id, c.__$seqval) end __$min_op_2289239F, __$count_2289239F, 
		m.__$update_mask , t.[Id], t.[TransactionType], t.[CheckInDate], t.[CheckOutDate], t.[Nights], t.[TotalAmount], t.[RoomType], t.[Children], t.[Adults], t.[RoomRate], t.[VisitReview], t.[MinibarUsage], t.[RoomCharge], t.[RoomServiceAmount], t.[TVUsageStatistics], t.[Complain], t.[UsedAmenities], t.[ReservationSource], t.[Package], t.[UsageWhatsappConcierge], t.[BreakfastIncluded], t.[HotelName], t.[HotelLocatoin], t.[VisitPurpose], t.[DiscountType], t.[Venue], t.[Location], t.[VisitDate], t.[VisitTime], t.[NumberOfGuests], t.[AverageAmount], t.[OrderDetails], t.[PaymentType], t.[Source], t.[IsHotelGuest], t.[VisitNumber], t.[TableType], t.[ServiceType], t.[EventName], t.[EventType], t.[FavoriteProcedure], t.[FavoriteSpecialist], t.[FavoriteCategory], t.[ExtraProducts], t.[Membership], t.[CreatedBy], t.[CreatedOn], t.[UpdatedOn], t.[IsProcessed], t.[ProcessDate], t.[ItemId], t.[WeatherTemperature], t.[HotelPackage], t.[ExchangeRateUSD], t.[OperatorDetails], t.[PaymentMethod]
		from [cdc].[dbo_GUEST_TRANSACTION_CT] t with (nolock) inner join 
		(	select  r.[Id],
		    count(*) as __$count_2289239F, 
		    [sys].[ORMask](r.__$update_mask) as __$update_mask
			from [cdc].[dbo_GUEST_TRANSACTION_CT] r with (nolock)
			where  (r.__$start_lsn <= @to_lsn)
			and (r.__$start_lsn >= @from_lsn)
			group by   r.[Id]) m
		on t.__$seqval = ( select top 1 c.__$seqval from [cdc].[dbo_GUEST_TRANSACTION_CT] c with (nolock) where  ( (c.[Id] = t.[Id]) )  and c.__$start_lsn <= @to_lsn and c.__$start_lsn >= @from_lsn order by c.__$start_lsn desc, c.__$command_id desc, c.__$seqval desc ) and
		    ( (t.[Id] = m.[Id]) ) 	
		where lower(rtrim(ltrim(@row_filter_option))) = N'all with mask'
			and ( [sys].[fn_cdc_check_parameters]( N'dbo_GUEST_TRANSACTION', @from_lsn, @to_lsn, lower(rtrim(ltrim(@row_filter_option))), 1) = 1)
			and (t.__$start_lsn <= @to_lsn)
			and (t.__$start_lsn >= @from_lsn)
			and ((t.__$operation = 2) or (t.__$operation = 4) or 
				 ((t.__$operation = 1) and
				  (2 not in 
				 		(	select top 1 c.__$operation
							from [cdc].[dbo_GUEST_TRANSACTION_CT] c with (nolock)
							where  ( (c.[Id] = t.[Id]) )  
							and ((c.__$operation = 2) or (c.__$operation = 4) or (c.__$operation = 1))
							and (c.__$start_lsn <= @to_lsn)
							and (c.__$start_lsn >= @from_lsn)
							order by c.__$start_lsn, c.__$command_id, c.__$seqval
						 ) 
	 			   )
	 			 )
	 			) 
			and t.__$operation = (
				select
					max(mo.__$operation)
				from
					[cdc].[dbo_GUEST_TRANSACTION_CT] as mo with (nolock)
				where
					mo.__$seqval = t.__$seqval
					and 
					 ( (t.[Id] = mo.[Id]) ) 
				group by
					mo.__$seqval
			)	
	) Q
	
	union all
	
		select t.__$start_lsn as __$start_lsn,
		case t.__$operation
			when 1 then 1
			else 5
		end as __$operation,
		null as __$update_mask , t.[Id], t.[TransactionType], t.[CheckInDate], t.[CheckOutDate], t.[Nights], t.[TotalAmount], t.[RoomType], t.[Children], t.[Adults], t.[RoomRate], t.[VisitReview], t.[MinibarUsage], t.[RoomCharge], t.[RoomServiceAmount], t.[TVUsageStatistics], t.[Complain], t.[UsedAmenities], t.[ReservationSource], t.[Package], t.[UsageWhatsappConcierge], t.[BreakfastIncluded], t.[HotelName], t.[HotelLocatoin], t.[VisitPurpose], t.[DiscountType], t.[Venue], t.[Location], t.[VisitDate], t.[VisitTime], t.[NumberOfGuests], t.[AverageAmount], t.[OrderDetails], t.[PaymentType], t.[Source], t.[IsHotelGuest], t.[VisitNumber], t.[TableType], t.[ServiceType], t.[EventName], t.[EventType], t.[FavoriteProcedure], t.[FavoriteSpecialist], t.[FavoriteCategory], t.[ExtraProducts], t.[Membership], t.[CreatedBy], t.[CreatedOn], t.[UpdatedOn], t.[IsProcessed], t.[ProcessDate], t.[ItemId], t.[WeatherTemperature], t.[HotelPackage], t.[ExchangeRateUSD], t.[OperatorDetails], t.[PaymentMethod]
		from [cdc].[dbo_GUEST_TRANSACTION_CT] t  with (nolock)
		where lower(rtrim(ltrim(@row_filter_option))) = N'all with merge'
			and ( [sys].[fn_cdc_check_parameters]( N'dbo_GUEST_TRANSACTION', @from_lsn, @to_lsn, lower(rtrim(ltrim(@row_filter_option))), 1) = 1)
			and (t.__$start_lsn <= @to_lsn)
			and (t.__$start_lsn >= @from_lsn)
			and (t.__$seqval = ( select top 1 c.__$seqval from [cdc].[dbo_GUEST_TRANSACTION_CT] c with (nolock) where  ( (c.[Id] = t.[Id]) )  and c.__$start_lsn <= @to_lsn and c.__$start_lsn >= @from_lsn order by c.__$start_lsn desc, c.__$command_id desc, c.__$seqval desc ))
			and ((t.__$operation = 2) or (t.__$operation = 4) or 
				 ((t.__$operation = 1) and 
				   (2 not in 
				 		(	select top 1 c.__$operation
							from [cdc].[dbo_GUEST_TRANSACTION_CT] c with (nolock)
							where  ( (c.[Id] = t.[Id]) )  
							and ((c.__$operation = 2) or (c.__$operation = 4) or (c.__$operation = 1))
							and (c.__$start_lsn <= @to_lsn)
							and (c.__$start_lsn >= @from_lsn)
							order by c.__$start_lsn, c.__$command_id, c.__$seqval
						 ) 
	 				)
	 			 )
	 			)
			and t.__$operation = (
				select
					max(mo.__$operation)
				from
					[cdc].[dbo_GUEST_TRANSACTION_CT] as mo with (nolock)
				where
					mo.__$seqval = t.__$seqval
					and 
					 ( (t.[Id] = mo.[Id]) ) 
				group by
					mo.__$seqval
			)

    go

    grant select on cdc.fn_cdc_get_net_changes_dbo_GUEST_TRANSACTION to [public]
    go

