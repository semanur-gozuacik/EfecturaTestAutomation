
	create function [cdc].[fn_cdc_get_all_changes_dbo_GUEST_TRANSACTION]
	(	@from_lsn binary(10),
		@to_lsn binary(10),
		@row_filter_option nvarchar(30)
	)
	returns table
	return
	
	select NULL as __$start_lsn,
		NULL as __$seqval,
		NULL as __$operation,
		NULL as __$update_mask, NULL as [Id], NULL as [TransactionType], NULL as [CheckInDate], NULL as [CheckOutDate], NULL as [Nights], NULL as [TotalAmount], NULL as [RoomType], NULL as [Children], NULL as [Adults], NULL as [RoomRate], NULL as [VisitReview], NULL as [MinibarUsage], NULL as [RoomCharge], NULL as [RoomServiceAmount], NULL as [TVUsageStatistics], NULL as [Complain], NULL as [UsedAmenities], NULL as [ReservationSource], NULL as [Package], NULL as [UsageWhatsappConcierge], NULL as [BreakfastIncluded], NULL as [HotelName], NULL as [HotelLocatoin], NULL as [VisitPurpose], NULL as [DiscountType], NULL as [Venue], NULL as [Location], NULL as [VisitDate], NULL as [VisitTime], NULL as [NumberOfGuests], NULL as [AverageAmount], NULL as [OrderDetails], NULL as [PaymentType], NULL as [Source], NULL as [IsHotelGuest], NULL as [VisitNumber], NULL as [TableType], NULL as [ServiceType], NULL as [EventName], NULL as [EventType], NULL as [FavoriteProcedure], NULL as [FavoriteSpecialist], NULL as [FavoriteCategory], NULL as [ExtraProducts], NULL as [Membership], NULL as [CreatedBy], NULL as [CreatedOn], NULL as [UpdatedOn], NULL as [IsProcessed], NULL as [ProcessDate], NULL as [ItemId], NULL as [WeatherTemperature], NULL as [HotelPackage], NULL as [ExchangeRateUSD], NULL as [OperatorDetails], NULL as [PaymentMethod]
	where ( [sys].[fn_cdc_check_parameters]( N'dbo_GUEST_TRANSACTION', @from_lsn, @to_lsn, lower(rtrim(ltrim(@row_filter_option))), 0) = 0)

	union all
	
	select t.__$start_lsn as __$start_lsn,
		t.__$seqval as __$seqval,
		t.__$operation as __$operation,
		t.__$update_mask as __$update_mask, t.[Id], t.[TransactionType], t.[CheckInDate], t.[CheckOutDate], t.[Nights], t.[TotalAmount], t.[RoomType], t.[Children], t.[Adults], t.[RoomRate], t.[VisitReview], t.[MinibarUsage], t.[RoomCharge], t.[RoomServiceAmount], t.[TVUsageStatistics], t.[Complain], t.[UsedAmenities], t.[ReservationSource], t.[Package], t.[UsageWhatsappConcierge], t.[BreakfastIncluded], t.[HotelName], t.[HotelLocatoin], t.[VisitPurpose], t.[DiscountType], t.[Venue], t.[Location], t.[VisitDate], t.[VisitTime], t.[NumberOfGuests], t.[AverageAmount], t.[OrderDetails], t.[PaymentType], t.[Source], t.[IsHotelGuest], t.[VisitNumber], t.[TableType], t.[ServiceType], t.[EventName], t.[EventType], t.[FavoriteProcedure], t.[FavoriteSpecialist], t.[FavoriteCategory], t.[ExtraProducts], t.[Membership], t.[CreatedBy], t.[CreatedOn], t.[UpdatedOn], t.[IsProcessed], t.[ProcessDate], t.[ItemId], t.[WeatherTemperature], t.[HotelPackage], t.[ExchangeRateUSD], t.[OperatorDetails], t.[PaymentMethod]
	from [cdc].[dbo_GUEST_TRANSACTION_CT] t with (nolock)    
	where (lower(rtrim(ltrim(@row_filter_option))) = 'all')
	    and ( [sys].[fn_cdc_check_parameters]( N'dbo_GUEST_TRANSACTION', @from_lsn, @to_lsn, lower(rtrim(ltrim(@row_filter_option))), 0) = 1)
		and (t.__$operation = 1 or t.__$operation = 2 or t.__$operation = 4)
		and (t.__$start_lsn <= @to_lsn)
		and (t.__$start_lsn >= @from_lsn)
		
	union all	
		
	select t.__$start_lsn as __$start_lsn,
		t.__$seqval as __$seqval,
		t.__$operation as __$operation,
		t.__$update_mask as __$update_mask, t.[Id], t.[TransactionType], t.[CheckInDate], t.[CheckOutDate], t.[Nights], t.[TotalAmount], t.[RoomType], t.[Children], t.[Adults], t.[RoomRate], t.[VisitReview], t.[MinibarUsage], t.[RoomCharge], t.[RoomServiceAmount], t.[TVUsageStatistics], t.[Complain], t.[UsedAmenities], t.[ReservationSource], t.[Package], t.[UsageWhatsappConcierge], t.[BreakfastIncluded], t.[HotelName], t.[HotelLocatoin], t.[VisitPurpose], t.[DiscountType], t.[Venue], t.[Location], t.[VisitDate], t.[VisitTime], t.[NumberOfGuests], t.[AverageAmount], t.[OrderDetails], t.[PaymentType], t.[Source], t.[IsHotelGuest], t.[VisitNumber], t.[TableType], t.[ServiceType], t.[EventName], t.[EventType], t.[FavoriteProcedure], t.[FavoriteSpecialist], t.[FavoriteCategory], t.[ExtraProducts], t.[Membership], t.[CreatedBy], t.[CreatedOn], t.[UpdatedOn], t.[IsProcessed], t.[ProcessDate], t.[ItemId], t.[WeatherTemperature], t.[HotelPackage], t.[ExchangeRateUSD], t.[OperatorDetails], t.[PaymentMethod]
	from [cdc].[dbo_GUEST_TRANSACTION_CT] t with (nolock)     
	where (lower(rtrim(ltrim(@row_filter_option))) = 'all update old')
	    and ( [sys].[fn_cdc_check_parameters]( N'dbo_GUEST_TRANSACTION', @from_lsn, @to_lsn, lower(rtrim(ltrim(@row_filter_option))), 0) = 1)
		and (t.__$operation = 1 or t.__$operation = 2 or t.__$operation = 4 or
		     t.__$operation = 3 )
		and (t.__$start_lsn <= @to_lsn)
		and (t.__$start_lsn >= @from_lsn)

    go

    grant select on cdc.fn_cdc_get_all_changes_dbo_GUEST_TRANSACTION to [public]
    go

