CREATE FUNCTION [dbo].[GetChildrensByCategory](@categoryId int)
                        RETURNS TABLE
                        AS RETURN
                           WITH cte AS 
	                         (
	                          SELECT a.Id,a.Code,a.FileId, a.en_US, a.tr_TR, a.ru_RU,a.ItemType,a.UserPermissions,a.GroupPermissions,a.ParentId
	                          FROM Categories a
	                          WHERE Id = @categoryId
	                          UNION ALL
	                          SELECT a.Id,a.Code,a.FileId, a.en_US, a.tr_TR, a.ru_RU,a.ItemType,a.UserPermissions,a.GroupPermissions,a.ParentId
	                          FROM Categories a JOIN cte c ON a.parentId = c.id
	                          )
                          SELECT Id,Code,FileId, en_US, tr_TR, ru_RU, ItemType, UserPermissions, GroupPermissions, ParentId
                          FROM cte

go

