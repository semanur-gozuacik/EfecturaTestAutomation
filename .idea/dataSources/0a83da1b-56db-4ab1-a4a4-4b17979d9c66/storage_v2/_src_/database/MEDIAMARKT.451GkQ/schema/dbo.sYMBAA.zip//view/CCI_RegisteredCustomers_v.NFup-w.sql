create   view [dbo].[CCI_RegisteredCustomers_v] as
with sel3 as (
select max(SalesCenterText__c) as SalesCenterText__c
	  ,Code__c
	  ,max(Outlet_Name__c) as Outlet_Name__c
	  ,max(ManagementChannel__c) as ManagementChannel__c
	  ,max(ASM_Code__c) as ASM_Code__c
	  ,max(Approver_Sales_Developer__c) as Approver_Sales_Developer__c
	  ,max(VPO__c) as VPO__c
	  ,max(LoyaltyActivation_Date__c) as LoyaltyActivation_Date__c
	  ,max(LastLoginDate__c) as LastLoginDate__c
	  ,max(balance__c) as balance__c
	  ,ItemId
	from (
			select
			case when sel.AttCode='SalesCenterText__c' then sel.ValueString else null end as SalesCenterText__c,
			sel.SKU as Code__c,
			case when sel.AttCode='Outlet_Name__c' then sel.ValueString else null end as Outlet_Name__c,
			case when sel.AttCode='ManagementChannel__c' then sel.OptionName else null end as ManagementChannel__c,
			case when sel.AttCode='ASM_Code__c' then sel.ValueString else null end as ASM_Code__c,
			case when sel.AttCode='Approver_Sales_Developer__c' then sel.OptionName else null end as Approver_Sales_Developer__c,
			case when sel.AttCode='VPO__c' then sel.ValueString else null end as VPO__c,
			case when sel.AttCode='LoyaltyActivation_Date__c' then sel.ValueDateTime else null end as LoyaltyActivation_Date__c,
			case when sel.AttCode='LastLoginDate__c' then sel.ValueDateTime else null end as LastLoginDate__c,
			case when sel.AttCode='AccountBalance__c' then floor(sel.ValueDecimal) else null end as balance__c,
			sel.ItemId
			from
				(
				select it.SKU, att.Code as AttCode, iv.*, ato.en_US as OptionName
				from [dbo].Items it
				join [dbo].ItemValues iv on iv.ItemId=it.Id
				join [dbo].Attributes att on att.Id=iv.AttributeId
				left join [dbo].AttributeOptions ato on ato.Id=iv.ValueInt
				where it.Type=52
				and att.Code in ('SalesCenterText__c','Outlet_Name__c','ManagementChannel__c','ASM_Code__c','Approver_Sales_Developer__c'
				,'VPO__c','LoyaltyActivation_Date__c','LastLoginDate__c','AccountBalance__c')
				--and it.Id=6443
				) sel
			) sel2
	group by Code__c,ItemId)
select SalesCenterText__c
	  ,Code__c
	  ,Outlet_Name__c
	  ,ManagementChannel__c
	  ,ASM_Code__c
	  ,Approver_Sales_Developer__c
	  ,VPO__c
	  ,min(asso2.CreatedAt) as LoyaltyActivation_Date__c
	  ,max(asso2.LastLoggedIn) as LastLoginDate__c
	  ,sum(cb.Point) as EarnedPoints__c
	  ,balance__c
	  ,case when asso.Id is not null then '1' else '0' end as Contracted__c 
	 from sel3
left join Callbacks cb on cb.DeviceId=sel3.ItemId
left join (select assoc.Id, assoc.FirstItemId 
				from Associations assoc 
				join AssociationTypes ast on ast.Id=assoc.AssociationTypeId and ast.Code='ACCOUNT_CONTRACT') asso on asso.FirstItemId=sel3.ItemId
join (select assoc2.Id, assoc2.FirstItemId, us.LastLoggedIn, us.CreatedAt 
				from Associations assoc2 
				join AssociationTypes ast2 on ast2.Id=assoc2.AssociationTypeId and ast2.Code='ACCOUNT_MRP'
				join Items it2 on it2.Id=assoc2.SecondItemId
				join [User] us on us.Id=it2.UserId) asso2 on asso2.FirstItemId=sel3.ItemId
group by SalesCenterText__c
	  ,Code__c
	  ,Outlet_Name__c
	  ,ManagementChannel__c
	  ,ASM_Code__c
	  ,Approver_Sales_Developer__c
	  ,VPO__c
	  ,balance__c
	  ,asso.Id
go

