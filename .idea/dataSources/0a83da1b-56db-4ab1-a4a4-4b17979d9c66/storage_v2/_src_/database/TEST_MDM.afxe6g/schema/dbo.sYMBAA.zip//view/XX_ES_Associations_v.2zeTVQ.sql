create   view XX_ES_Associations_v
as
SELECT assoc.Id as AssociationId 
  ,assoc.AssociationTypeId as AssociationTypeId
    ,assoc.FirstItemId
  ,assoc.SecondItemId
  ,assoc.OrderId
  ,assoc.OrderId2
  ,assoc.StartDate
  ,assoc.EndDate
    ,assot.Code as AssociationTypeCode
  ,assot.en_US as AssociationTypeen
  ,assot.ru_RU as AssociationTyperu
  ,assot.tr_TR as AssociationTypetr
  ,assot.PrimaryItemType
  ,assot.SecondaryItemType
  ,assotr.LanguageCode
    ,assotr.Text as AssociationTypeTranslation
  FROM [dbo].Associations assoc
  JOIN [dbo].AssociationTypes assot on assot.Id = assoc.AssociationTypeId
  LEFT JOIN [dbo].AssociationTypeTranlations assotr on assot.Id = assotr.AssociationTypeId
go

