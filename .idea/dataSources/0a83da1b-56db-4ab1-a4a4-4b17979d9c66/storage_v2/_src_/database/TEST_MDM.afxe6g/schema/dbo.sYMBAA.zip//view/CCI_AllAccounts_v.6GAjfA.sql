create   view [dbo].[CCI_AllAccounts_v] as
with sel3 as
(
select Code
  ,max(Address) as Address
  ,max(ASM) as ASM
  ,max(BusinessType) as BusinessType
  ,max(BusinessTypeExtent) as BusinessTypeExtent
  ,max(City) as City
  ,max(ClusterCode) as ClusterCode
  ,max(ContactPerson) as ContactPerson
  ,max(CountryCode) as CountryCode
  ,max(DistributionChannel) as DistributionChannel
  ,max(DistributorCode) as DistributorCode
  ,max(KAEX) as KAEX
  ,max(KAM) as KAM
  ,max(LegalName) as LegalName
  ,max(LocationCode) as LocationCode
  ,max(LocationText) as LocationText
  ,max(MainChannel) as MainChannel
  ,max(ManagementChannel) as ManagementChannel
  ,max(OpeningDate) as OpeningDate
  ,max(OutletName) as OutletName
  ,max(Preseller) as Preseller
  ,max(Route) as Route
  ,max(SalesCenter) as SalesCenter
  ,max(SalesDeveloper) as SalesDeveloper
  ,max(Segment) as Segment
  ,max(SubTradeChannel) as SubTradeChannel
  ,max(AccSuppressCode) as AccSuppressCode
  ,max(SuppressDate) as SuppressDate
  ,max(TradeChannel) as TradeChannel
  ,max(TradeGroup) as TradeGroup
  ,max(VATNo) as VATNo
  ,max(VPO) as VPO
  ,max(Balance) as Balance
  ,ItemId
from
(
-- OptionName -- Simple Select
--ValueString -- text
select
sel.SKU as Code,
case when sel.AttCode='Address__c' then sel.ValueString else null end as Address,
case when sel.AttCode='ASM__c' then sel.ValueString else null end as ASM,
case when sel.AttCode='Business_Type__c' then sel.OptionName else null end as BusinessType,
case when sel.AttCode='Business_Type_extent__c' then sel.OptionName else null end as BusinessTypeExtent,
case when sel.AttCode='City__c' then sel.OptionName else null end as City,
case when sel.AttCode='ClusterCode__c' then sel.OptionName else null end as ClusterCode,
case when sel.AttCode='Contact_Person__c' then sel.ValueString else null end as ContactPerson,
case when sel.AttCode='CountryCode__c' then  floor(sel.ValueDecimal) else null end as CountryCode,
case when sel.AttCode='Distribution_Channel__c' then sel.OptionName else null end as DistributionChannel,
case when sel.AttCode='DistributorCode__c' then sel.ValueString else null end as DistributorCode,
case when sel.AttCode='KAEX__c' then sel.OptionName else null end as KAEX,
case when sel.AttCode='KAM__c' then sel.OptionName else null end as KAM,
case when sel.AttCode='LegalName__c' then sel.ValueString else null end as LegalName,
case when sel.AttCode='LocationCode__c' then sel.ValueString else null end as LocationCode,
case when sel.AttCode='LocationText__c' then sel.ValueString else null end as LocationText,
case when sel.AttCode='MainChannel__c' then sel.OptionName else null end as MainChannel,
case when sel.AttCode='ManagementChannel__c' then sel.OptionName  else null end as ManagementChannel,
case when sel.AttCode='OpeningDate__c' then sel.ValueDateTime else null end as OpeningDate,
case when sel.AttCode='Outlet_Name__c' then sel.ValueString else null end as OutletName,
case when sel.AttCode='Seller__c' then sel.OptionName else null end as Preseller,
case when sel.AttCode='Route__c' then sel.ValueString else null end as Route,
case when sel.AttCode='SalesCenter__c' then sel.OptionName else null end as SalesCenter,
case when sel.AttCode='SalesDeveloper__c' then sel.OptionName else null end as SalesDeveloper,
case when sel.AttCode='Segment__c' then sel.OptionName else null end as Segment,
case when sel.AttCode='Sub_Trade_Channel__c' then sel.OptionName else null end as SubTradeChannel,
case when sel.AttCode='Acc_SuppressCode__c' then sel.OptionName else null end as AccSuppressCode,
case when sel.AttCode='SuppressDate__c' then sel.ValueDateTime else null end as SuppressDate,
case when sel.AttCode='Trade_Channel__c' then sel.OptionName else null end as TradeChannel,
case when sel.AttCode='TradeGroup__c' then sel.OptionName else null end as TradeGroup,
case when sel.AttCode='VATNo__c' then sel.ValueString else null end as VATNo,
case when sel.AttCode='VPO__c' then sel.ValueString else null end as VPO,
case when sel.AttCode='AccountBalance__c' then floor(sel.ValueDecimal) else null end as Balance,
sel.ItemId
from
(
select it.SKU, att.Code as AttCode, iv.*, ato.en_US as OptionName
from [dbo].Items it
left join [dbo].ItemValues iv on iv.ItemId=it.Id
left join [dbo].Attributes att on att.Id=iv.AttributeId
left join [dbo].AttributeOptions ato on ato.Id=iv.ValueInt
where it.Type=52
and att.Code in ('Address__c','ASM__c','Business_Type__c','Business_Type_extent__c','City__c'
,'ClusterCode__c','Contact_Person__c','CountryCode__c','Distribution_Channel__c','DistributorCode__c','KAEX__c'
,'KAM__c','LegalName__c','LocationCode__c','LocationText__c','MainChannel__c','ManagementChannel__c','OpeningDate__c','Outlet_Name__c','Seller__c','Route__c','SalesCenter__c',
'SalesDeveloper__c','Segment__c','Sub_Trade_Channel__c','Acc_SuppressCode__c','SuppressDate__c','Trade_Channel__c','TradeGroup__c','VATNo__c','VPO__c'
,'AccountBalance__c', 'RedeemedPoints__c')
--and ItemId='6909'
) sel
) sel2
group by Code,ItemId
)
select
sel3.Code, Address
  ,ASM
  ,BusinessType
  ,BusinessTypeExtent
  ,City
  ,ClusterCode
  ,ContactPerson
  ,CountryCode
  ,DistributionChannel
  ,DistributorCode
  ,KAEX
  ,KAM
  ,LegalName
  ,LocationCode
  ,LocationText
  ,MainChannel
  ,ManagementChannel
  ,OpeningDate
  ,OutletName
  ,Preseller
  ,Route
  ,SalesCenter
  ,SalesDeveloper
  ,Segment
  ,SubTradeChannel
  ,AccSuppressCode
  ,SuppressDate
  ,TradeChannel
  ,TradeGroup
  ,VATNo
  ,VPO
  ,Balance
  ,(select sum(cb.Point) from Callbacks cb where cb.DeviceId=sel3.ItemId and cb.Status=1) as EarnedPoints
  ,(select sum(up.Cost) from [dbo].UserPayments up where up.PhoneNumber=sel3.ItemId) as RedeemedPoints
  ,ItemId
  --,cb.DeviceId
from sel3
--left join Callbacks cb on cb.DeviceId=sel3.ItemId and cb.Status=1
--left join (select  distinct Id,PhoneNumber,Cost from [dbo].[UserPayments]) up on up.PhoneNumber=sel3.ItemId
where 1=1
--group by
--   sel3.Code, Address
--  ,ASM
--  ,BusinessType
--  ,BusinessTypeExtent
--  ,City
--  ,ClusterCode
--  ,ContactPerson
--  ,CountryCode
--  ,DistributionChannel
--  ,DistributorCode
--  ,KAEX
--  ,KAM
--  ,LegalName
--  ,LocationCode
--  ,LocationText
--  ,MainChannel
--  ,ManagementChannel
--  ,OpeningDate
--  ,OutletName
--  ,Preseller
--  ,Route
--  ,SalesCenter
--  ,SalesDeveloper
--  ,Segment
--  ,SubTradeChannel
--  ,AccSuppressCode
--  ,SuppressDate
--  ,TradeChannel
--  ,TradeGroup
--  ,VATNo
--  ,VPO
--  ,Balance
--  ,ItemId
--  ,cb.DeviceId
go

