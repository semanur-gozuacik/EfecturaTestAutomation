create   view XX_ES_Items_v
as
SELECT item.Id as itemid
    ,item.SKU as sku
    ,item.Type as itemtypeid
    ,item.FamilyId as familyid
    ,item.en_US
    ,item.ru_RU
    ,item.tr_TR
    ,item.Code as code
    ,item.Path as image
	,item.StatusItem
	,item.ItemStatusesId
	,its.Label as StatusLabel
	,item.CreatedBy
	,item.CreatedOn
	,item.UpdatedBy
	,item.UpdatedOn
    ,fam.Code as familycode
    ,fam.en_US as familyen
    ,fam.tr_TR as familytr
    ,fam.ru_RU as familyru
    ,v.AttributeId as attributeId
    ,att.Code as AttCode
    ,att.en_US as attributeen
    ,att.tr_TR as attributetr
    ,att.ru_RU as attributeru
	,att.attribute_type as attribute_type
	,v.Id as ItemValueId
    ,v.ValueInt as valueint
    ,v.ValueString as valuestring
    ,v.ValueDateTime as valuedatetime
    ,v.ValueBool as valuebool
    ,v.ValueClob as valueclob
    ,v.ValueDecimal as valuedecimal
      ,itr.LanguageCode
  ,itr.Text as ItemTranslation
    ,famtr.Text as FamilyTranslation
    ,ivtr.Text as ItemValueTranslation
    ,attr.Text as AttributeTranslation
    ,ato.Code as AttributeOptionCode
  ,ato.en_US as AttributeOptionen
  ,ato.ru_RU as AttributeOptionru
  ,ato.tr_TR as AttributeOptiontr
  ,atotr.Text as AttributeOptionTranslation
FROM Items item 
LEFT JOIN ItemTranslations itr on item.Id=itr.ItemId
JOIN Families fam on item.FamilyId = fam.Id
LEFT JOIN FamilyTranslations famtr on fam.Id = famtr.FamilyId and itr.LanguageCode=famtr.LanguageCode
JOIN ItemValues v on item.Id = v.ItemId
LEFT JOIN ItemValueTranslations ivtr on ivtr.ItemValueId = v.Id and itr.LanguageCode=ivtr.LanguageCode
JOIN Attributes att on att.Id = v.AttributeId 
LEFT JOIN AttributeTranslations attr on att.Id = attr.AttributeId and itr.LanguageCode=attr.LanguageCode
LEFT JOIN AttributeOptions ato on ato.Id=v.ValueInt and ato.AttributeId=v.AttributeId
LEFT JOIN AttributeOptionTranslations atotr on ato.Id=atotr.AttributeOptionId and itr.LanguageCode=atotr.LanguageCode
LEFT JOIN ItemStatuses its on its.Id = item.ItemStatusesId

go

