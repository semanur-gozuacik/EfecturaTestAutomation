create   view [dbo].[CCI_GiftOrderReport_v]
as
select upay.Msisdn as PhoneNumber
	  ,upay.Type as GiftType
	  ,upay.DateCreate as Date
	  ,upay.Id as OrderID
	  ,upay.Type as Vendor --need to open new attribute on Gift when will have other Vendors
	  ,it.SKU as SKU
	  ,iv.ValueString as GiftName
	  ,upay.Cost as Point
	  ,upay.Cost*100/(100+upay.[Percent]) as Price
	  --,cast(upay.Cost as decimal(10,2)) as Point
	  --,cast(upay.Cost*100/(100+upay.[Percent]) as decimal(10,2)) Price
	  ,upay.Status Status
	  ,it2.SKU OutletNo
	  ,acc.Account_Name as OutletName
	  ,upay.UserId as UserID
	  ,u.UserName as UserName 
from [dbo].UserPayments upay
join [dbo].[User] u on upay.UserID = u.Id
join [dbo].[Items] it on it.Id = upay.GiftId
join [dbo].[ItemValues] iv on iv.ItemId = it.Id 
join dbo.Attributes att on att.Id = iv.AttributeId and att.Code in ('XGIFT_NAME')
join [dbo].[Items] it2 on it2.Id = upay.PhoneNumber
left join (select iv2.ValueString as Account_Name, iv2.ItemId from [dbo].[ItemValues] iv2 
							join dbo.Attributes att2 on att2.Id = iv2.AttributeId 
							and att2.Code in ('Account_Name')
							) acc on acc.ItemId = it2.Id
go

