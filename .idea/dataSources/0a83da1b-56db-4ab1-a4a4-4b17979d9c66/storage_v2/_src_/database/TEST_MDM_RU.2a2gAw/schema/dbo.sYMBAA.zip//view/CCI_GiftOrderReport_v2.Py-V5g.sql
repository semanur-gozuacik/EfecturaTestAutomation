
 CREATE   VIEW dbo.CCI_GiftOrderReport_v2 AS SELECT    upay.Type AS GiftType,    it.SKU AS Gift_Code,    iv.ValueString AS GiftName,    upay.Type AS Vendor,    upay.Id AS OrderID, upay.MaskedCardNo AS MaskedCardNumber,    upay.DateCreate AS Order_Date,    CASE        WHEN upay.Status = 0 THEN 'AutoApproved'        WHEN upay.Status = 1 THEN 'Pending'        WHEN upay.Status = 2 THEN 'Approved'        WHEN upay.Status = 3 THEN 'Rejected'        WHEN upay.Status = 4 THEN 'Error'        WHEN upay.Status = 5 THEN 'Inactive'    END AS STATUS,    upay.Cost AS PointsRedeemed,    (upay.Cost * 100) / (100 + upay.[Percent]) AS GiftCost,    it2.SKU AS AccountNumber,    acc.Account_Name AS AccountName,    upay.Msisdn AS SenderPhone,    mel_2.Name as Name,    mel_2.Surname as Surname,    mel_2.UserNationalID as UserNationalID,    mel_2.UserName as UserName,    mel_2.PhoneNumber AS ReceiverPhone FROM    dbo.UserPayments AS upay    INNER JOIN dbo.Items AS it ON it.Id = upay.GiftId    INNER JOIN dbo.ItemValues AS iv ON iv.ItemId = it.Id    AND iv.Locale_Code = 'en-US'    INNER JOIN dbo.Attributes AS att ON att.Id = iv.AttributeId    AND att.Code IN ('XGIFT_NAME')    INNER JOIN dbo.Items AS it2 ON it2.Id = upay.PhoneNumber    LEFT OUTER JOIN (        SELECT            iv2.ValueString AS Account_Name,            iv2.ItemId        FROM            dbo.ItemValues AS iv2            INNER JOIN dbo.Attributes AS att2 ON att2.Id = iv2.AttributeId            AND att2.Code IN ('Account_Name')            AND iv2.Locale_Code = 'en-US'    ) AS acc ON acc.ItemId = it2.Id	LEFT OUTER JOIN (		SELECT			Id,			UserName,			PhoneNumber,			MAX(				CASE					WHEN Code = 'First_name__c' THEN ValueString					ELSE NULL				END			) AS Name,			MAX(				CASE					WHEN Code = 'Last_name__c' THEN ValueString					ELSE NULL				END			) AS Surname,			MAX(				CASE					WHEN Code = 'NATIONAL_ID' THEN ValueString					ELSE NULL				END			) AS UserNationalID		FROM			(				SELECT					att.Code,					iv.ItemId,					it2.Id,					iv.ValueString,					u.UserName,					cu.PhoneNumber				FROM					dbo.Associations AS ass					INNER JOIN dbo.AssociationTypes AS ast ON ass.AssociationTypeId = ast.Id					AND ast.Code = 'Account_MRP'					INNER JOIN dbo.Items AS it2 ON ass.FirstItemId = it2.Id					INNER JOIN dbo.Items AS it ON ass.SecondItemId = it.Id					INNER JOIN dbo.ItemValues AS iv ON ass.SecondItemId = iv.ItemId					AND iv.Locale_Code = 'en-US'					INNER JOIN dbo.[User] u on u.Id = it.UserId					INNER JOIN dbo.[CCIUser] cu on cu.UserName = u.UserName					INNER JOIN dbo.Attributes AS att ON att.Id = iv.AttributeId					AND att.Code IN ('First_name__c', 'Last_name__c', 'NATIONAL_ID')			) AS a		GROUP BY			Id, UserName, PhoneNumber    ) AS mel_2 ON mel_2.Id = it2.Id 
go

 exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[21] 4[27] 2[33] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "upay"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 136
               Right = 211
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "u"
            Begin Extent = 
               Top = 138
               Left = 38
               Bottom = 268
               Right = 262
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "cu"
            Begin Extent = 
               Top = 270
               Left = 38
               Bottom = 400
               Right = 262
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "it"
            Begin Extent = 
               Top = 6
               Left = 249
               Bottom = 136
               Right = 434
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "iv"
            Begin Extent = 
               Top = 402
               Left = 38
               Bottom = 532
               Right = 257
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "att"
            Begin Extent = 
               Top = 534
               Left = 38
               Bottom = 664
               Right = 245
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "it2"
            Begin Extent = 
               Top = 666
               Left = 38
               Bottom = 796
               Right = 223
            End
            DisplayFlags = 280
            TopColumn = 0
       ', 'SCHEMA', 'dbo', 'VIEW', 'CCI_GiftOrderReport_v2'
 go

 exec sp_addextendedproperty 'MS_DiagramPane2', N'  End
         Begin Table = "acc"
            Begin Extent = 
               Top = 6
               Left = 472
               Bottom = 102
               Right = 643
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "mel_1"
            Begin Extent = 
               Top = 6
               Left = 681
               Bottom = 136
               Right = 851
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'CCI_GiftOrderReport_v2'
 go

 exec sp_addextendedproperty 'MS_DiagramPaneCount', 2, 'SCHEMA', 'dbo', 'VIEW', 'CCI_GiftOrderReport_v2'
 go

