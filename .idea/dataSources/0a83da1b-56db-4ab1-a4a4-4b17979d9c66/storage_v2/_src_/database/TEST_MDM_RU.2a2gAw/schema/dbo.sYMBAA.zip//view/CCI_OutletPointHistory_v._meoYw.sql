create   view [dbo].CCI_OutletPointHistory_v as
with sel3 as (
select Code__c
	  ,max(ManagementChannel__c) as ManagementChannel__c	  
	  ,max(SalesCenterText__c) as SalesCenterText__c
	  ,max(ASM__c) as ASM__c
	  ,max(Approver_Sales_Developer__c) as Approver_Sales_Developer__c
	  ,max(SalesDeveloper__c) as SalesDeveloper__c
	  ,max(DistributorName__c) as DistributorName__c
	  ,max(Seller__c) as Seller__c
	  ,max(Segment__c) as Segment__c
	  ,ItemId
from (
select
sel.SKU as Code__c,
case when sel.AttCode='ManagementChannel__c' then sel.OptionName else null end as ManagementChannel__c,
case when sel.AttCode='SalesCenterText__c' then sel.ValueString else null end as SalesCenterText__c,
case when sel.AttCode='ASM__c' then sel.OptionName else null end as ASM__c,
case when sel.AttCode='Approver_Sales_Developer__c' then sel.OptionName else null end as Approver_Sales_Developer__c,
case when sel.AttCode='SalesDeveloper__c' then sel.OptionName else null end as SalesDeveloper__c,
case when sel.AttCode='DistributorName__c' then sel.ValueString else null end as DistributorName__c,
case when sel.AttCode='Seller__c' then sel.OptionName else null end as Seller__c,
case when sel.AttCode='Segment__c' then sel.OptionName else null end as Segment__c,
sel.ItemId
from
(
select it.SKU, att.Code as AttCode, iv.*, ato.en_US as OptionName
from [dbo].Items it
left join [dbo].ItemValues iv on iv.ItemId=it.Id
left join [dbo].Attributes att on att.Id=iv.AttributeId
left join [dbo].AttributeOptions ato on ato.Id=iv.ValueInt
where it.Type=52
and att.Code in ('ManagementChannel__c','SalesCenterText__c','ASM__c','Approver_Sales_Developer__c','SalesDeveloper__c'
				,'DistributorName__c','Seller__c','Segment__c')
--and it.Id=6443
) sel
) sel2
group by Code__c,ItemId) 
select ManagementChannel__c
	  ,camp.SKU as CampaignCode
	  ,DateCallback as CallbackDate
	  ,SalesCenterText__c
	  ,ASM__c
	  ,Approver_Sales_Developer__c
	  ,SalesDeveloper__c
	  ,DistributorName__c
	  ,Seller__c
	  ,Code__c
	  ,Segment__c
	  ,Point as Point
from sel3
join [dbo].Callbacks cb on cb.DeviceId=sel3.ItemId
join [dbo].Items camp on camp.Id=cb.TaskId
where cb.callbackId in (9,11)


go

