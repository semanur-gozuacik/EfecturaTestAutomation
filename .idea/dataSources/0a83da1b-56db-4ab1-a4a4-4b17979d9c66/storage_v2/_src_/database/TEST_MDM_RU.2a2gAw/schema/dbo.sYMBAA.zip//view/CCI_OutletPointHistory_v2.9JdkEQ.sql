CREATE     view [dbo].[CCI_OutletPointHistory_v2]
AS
SELECT CallbackID, OutletCode, Account_Name, PhoneNumber, NULL AS MaskedCardNumber ,PointCreatedDate, ExpiredDate, Point, TransactionType, PointStatus, TaskId, TaskName
FROM   (SELECT it_2.CallbackID, it_2.OutletCode, acc.Account_Name, it_2.PhoneNumber, NULL AS MaskedCardNumber, it_2.PointCreatedDate, it_2.ExpiredDate, it_2.Point, it_2.TransactionType, it_2.PointStatus, it_2.TaskId, it2.en_US AS TaskName
            FROM   (SELECT it.Id, it.SKU AS OutletCode, itval.ValueString AS PhoneNumber, NULL AS MaskedCardNumber ,cb.Id AS CallbackID, cb.DateCallback AS PointCreatedDate, cb.DateEnd AS ExpiredDate, cb.Point, 
                                   CASE WHEN CallbackId = 11 THEN 'Welcome' WHEN CallbackId = 8 THEN 'Training' WHEN CallbackId = 9 THEN 'Campaign' WHEN CallbackId = 10 THEN 'Gift' WHEN CallbackId = 4 THEN 'Balance' WHEN CallbackId = 13 THEN 'Survey' WHEN CallbackId = 14 THEN 'PointExpiry' END AS TransactionType, 
                                   CASE WHEN Status = 1 THEN 'Approved' WHEN Status = 2 THEN 'Rejected' WHEN Status = 0 THEN 'Pending' END AS PointStatus, cb.TaskId
                        FROM   dbo.Items AS it WITH (NoLock) INNER JOIN
                                   dbo.Callbacks AS cb WITH (NoLock) ON cb.DeviceId = it.Id
    LEFT JOIN Associations as assco on assco.AssociationTypeId = (select Id from AssociationTypes where Code = 'ACCOUNT_MRP')
 AND assco.FirstItemId = cb.DeviceId
     LEFT JOIN ItemValues as itval on itval.ItemId = assco.SecondItemId AND itval.AttributeId = (select Id from Attributes where Code = 'Employee_Cellphone__c')
                      WHERE (1 = 1) AND (it.Type = 52) AND (cb.Status NOT IN ('2'))) AS it_2 INNER JOIN
                       dbo.Items AS it2 ON it_2.TaskId = it2.Id LEFT OUTER JOIN
                           (SELECT iv2.ValueString AS Account_Name, iv2.ItemId
                          FROM   dbo.ItemValues AS iv2 WITH (NoLock) INNER JOIN
                                     dbo.Attributes AS att2 WITH (NoLock) ON att2.Id = iv2.AttributeId AND att2.Code IN ('Account_Name') AND iv2.Locale_Code = 'en-US') AS acc ON acc.ItemId = it_2.Id
            UNION ALL
            SELECT it_1.CallbackID, it_1.OutletCode, acc_2.Account_Name, it_1.PhoneNumber, NULL AS MaskedCardNumber, it_1.PointCreatedDate, it_1.ExpiredDate, it_1.Point, it_1.TransactionType, it_1.PointStatus, it_1.TaskId, it2.en_US AS TaskName
            FROM   (SELECT it.Id, it.SKU AS OutletCode, itval.ValueString AS PhoneNumber, NULL AS MaskedCardNumber ,cb.Id AS CallbackID, cb.DateCallback AS PointCreatedDate, cb.DateEnd AS ExpiredDate, -1 * (cb.Point - cb.PointSpent) as Point, 'PointExpiry' AS TransactionType, 
                                   CASE WHEN Status = 1 THEN 'Approved' WHEN Status = 2 THEN 'Rejected' WHEN Status = 0 THEN 'Pending' END AS PointStatus, cb.TaskId
                        FROM   dbo.Items AS it WITH (NoLock) INNER JOIN
                                   dbo.Callbacks AS cb WITH (NoLock) ON cb.DeviceId = it.Id
	 LEFT JOIN Associations as assco on assco.AssociationTypeId = (select Id from AssociationTypes where Code = 'ACCOUNT_MRP')
 AND assco.FirstItemId = cb.DeviceId
     LEFT JOIN ItemValues as itval on itval.ItemId = assco.SecondItemId AND itval.AttributeId = (select Id from Attributes where Code = 'Employee_Cellphone__c')
                        WHERE (1 = 1) AND (cb.DateEnd <= GETDATE()) AND ((cb.Point - cb.PointSpent) > 0) AND (it.Type = 52) AND (cb.Status NOT IN ('2'))) AS it_1 INNER JOIN
                       dbo.Items AS it2 ON it_1.TaskId = it2.Id LEFT OUTER JOIN
                           (SELECT iv2.ValueString AS Account_Name, iv2.ItemId
                          FROM   dbo.ItemValues AS iv2 WITH (NoLock) INNER JOIN
                                     dbo.Attributes AS att2 WITH (NoLock) ON att2.Id = iv2.AttributeId AND att2.Code IN ('Account_Name') AND iv2.Locale_Code = 'en-US') AS acc_2 ON acc_2.ItemId = it_1.Id
            UNION ALL
            SELECT upay.Id AS CallbackID, it2.SKU AS OutletCode, acc_1.Account_Name, upay.Msisdn AS PhoneNumber, upay.MaskedCardNo AS MaskedCardNumber, upay.DateCreate AS PointCreatedDate, NULL AS ExpiredDate, upay.Cost * - 1 AS Point, 'Gift' AS TransactionType, 
                       CASE WHEN upay.Status = 0 THEN 'AutoApproved' WHEN upay.Status = 1 THEN 'Pending' WHEN upay.Status = 2 THEN 'Approved' WHEN upay.Status = 3 THEN 'Rejected' WHEN upay.Status = 4 THEN 'Error' WHEN upay.Status = 5 THEN 'Inactive' END AS PointStatus, upay.GiftId AS TaskId, 
                       upay.GiftName AS TaskName
            FROM   dbo.UserPayments AS upay WITH (NoLock) INNER JOIN
                       dbo.Items AS it WITH (NoLock) ON it.Id = upay.GiftId INNER JOIN
                       dbo.Items AS it2 WITH (NoLock) ON it2.Id = upay.PhoneNumber LEFT OUTER JOIN
                           (SELECT iv2.ValueString AS Account_Name, iv2.ItemId
                          FROM   dbo.ItemValues AS iv2 WITH (NoLock) INNER JOIN
                                     dbo.Attributes AS att2 WITH (NoLock) ON att2.Id = iv2.AttributeId AND att2.Code IN ('Account_Name') AND iv2.Locale_Code = 'en-US') AS acc_1 ON acc_1.ItemId = it2.Id
            WHERE (upay.Status NOT IN ('3'))) AS a
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[24] 4[1] 2[55] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "a"
            Begin Extent = 
               Top = 10
               Left = 67
               Bottom = 240
               Right = 341
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1174
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1354
         SortOrder = 1414
         GroupBy = 1350
         Filter = 1354
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'CCI_OutletPointHistory_v2'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 1, 'SCHEMA', 'dbo', 'VIEW', 'CCI_OutletPointHistory_v2'
go

