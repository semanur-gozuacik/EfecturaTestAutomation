CREATE FUNCTION GarbleString(@inputString varchar(max))
RETURNS varchar(max)
AS
BEGIN
    DECLARE @outputString varchar(max) = '';
    DECLARE @charIndex int = 1;
    DECLARE @atIndex int = CHARINDEX('@', @inputString);
    IF @atIndex = 0
        SET @atIndex = LEN(@inputString) + 1;
    WHILE @charIndex < @atIndex
    BEGIN
        DECLARE @charValue int = ASCII(SUBSTRING(@inputString, @charIndex, 1));
        SET @charValue = (@charValue * 3 + 7) % 26;
        SET @charValue = @charValue + ASCII('A');
        SET @outputString = @outputString + CHAR(@charValue);
        SET @charIndex = @charIndex + 1;
    END
    SET @outputString = @outputString + SUBSTRING(@inputString, @atIndex, LEN(@inputString) - @atIndex + 1);
    RETURN @outputString;
END
go

