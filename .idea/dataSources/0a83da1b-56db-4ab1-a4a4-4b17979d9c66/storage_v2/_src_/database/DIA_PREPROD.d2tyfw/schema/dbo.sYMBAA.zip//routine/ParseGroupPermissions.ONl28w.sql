CREATE FUNCTION [dbo].[ParseGroupPermissions] (@GroupPermissions NVARCHAR(MAX))
RETURNS @ParsedValues TABLE (
    UserGroupId INT
)
AS
BEGIN
    DECLARE @start INT = 1, @end INT, @UserGroupId INT, @HasView NVARCHAR(5), @MaxIterations INT = 1000, @CurrentIteration INT = 0

    WHILE @start > 0 AND @CurrentIteration < @MaxIterations
    BEGIN
        SET @CurrentIteration = @CurrentIteration + 1
        
        -- Find the starting position of the next "UserGroupId"
        SET @start = CHARINDEX('"UserGroupId":', @GroupPermissions, @start)
        IF @start > 0
        BEGIN
            -- Find the ending position of the "UserGroupId"
            SET @end = CHARINDEX(',', @GroupPermissions, @start)
            IF @end > @start
            BEGIN
                SET @UserGroupId = CAST(SUBSTRING(@GroupPermissions, @start + 14, @end - @start - 14) AS INT)
                
                -- Find the corresponding "HasView"
                SET @start = CHARINDEX('"HasView":', @GroupPermissions, @end)
                IF @start > @end
                BEGIN
                    SET @end = CHARINDEX('}', @GroupPermissions, @start)
                    IF @end > @start
                    BEGIN
                        SET @HasView = SUBSTRING(@GroupPermissions, @start + 10, @end - @start - 10)

                        -- If "HasView" is true, insert the UserGroupId into the table
                        IF @HasView = 'true'
                        BEGIN
                            INSERT INTO @ParsedValues (UserGroupId)
                            VALUES (@UserGroupId)
                        END

                        -- Move to the next record
                        SET @start = @end + 1
                    END
                    ELSE
                    BEGIN
                        -- If we can't find a valid ending position for "HasView", exit the loop
                        SET @start = 0
                    END
                END
                ELSE
                BEGIN
                    -- If we can't find a valid starting position for "HasView", exit the loop
                    SET @start = 0
                END
            END
            ELSE
            BEGIN
                -- If we can't find a valid ending position for "UserGroupId", exit the loop
                SET @start = 0
            END
        END
    END

    RETURN
END
go

