create   view XX_ES_Categories_v
as
SELECT cat.Id as CategoryId
    ,cat.Code as CategoryCode
  ,cat.GroupPermissions as GroupPermissions
  ,cat.UserPermissions as UserPermissions
  ,cat.en_US as Categoryen
  ,cat.ru_RU as Categoryru
  ,cat.tr_TR as Categorytr
  ,catr.LanguageCode as LanguageCode
    ,catr.Text as CategoryTranslation
    ,cati.Item_Id as ItemId
  FROM [dbo].[Categories] cat
  LEFT JOIN [dbo].[CategoryTranslations] catr on cat.Id = catr.CategoryId
  JOIN [dbo].[CategoryItems] cati on cat.Id = cati.Category_Id
go

