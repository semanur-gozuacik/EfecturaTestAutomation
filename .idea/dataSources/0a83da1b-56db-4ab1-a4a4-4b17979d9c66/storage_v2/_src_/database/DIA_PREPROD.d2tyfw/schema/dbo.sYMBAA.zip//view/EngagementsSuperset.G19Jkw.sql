CREATE VIEW EngagementsSuperset AS
select i.id as EventId,
a.SecondItemId as ContactId,
a2.SecondItemId as SharingId,
a3.FirstItemId as FrameId,
iv.ValueDateTime as EventStartDate,
iv2.ValueDateTime as EventEndDate,
iv7.ValueString as DIA_Event_Name,
iv8.ValueString as Roof_Name,
iv9.ValueString as Contact_FirstName,
iv10.ValueString as Contact_LastName,
iv11.ValueString as Phone_Number,
iv12.ValueString as Email,
aot3.Text as City,
aot2.Text as DIA_Event_Type,
aot1.Text as Related_Product_Family,
aot.Text as Kisi_Segment,
ad.City as KatilimCity,
Case when  iv13.ValueBool = 0 or iv13.ValueBool IS NULL Then 'Hayır' else 'Evet' end as 'DIA_Pricing',
Case when  IsInvited = 0 or IsInvited IS NULL Then 'Hayır' else 'Evet' end as 'IsInvited',
(select IsInvited where IsInvited = 1) as InvitedTrue,
Case when  IsFree = 0 or IsFree IS NULL Then 'Hayır' else 'Evet' end as 'IsFree',
Case when  IsPay = 0 or IsFree IS NULL Then 'Hayır' else 'Evet' end as 'IsPay',
Case when  IsJoin = 0 or IsJoin IS NULL Then 'Hayır' else 'Evet' end as 'IsJoin',
(select IsJoin where IsJoin = 1) as JoinedTrue,
Case when  IsGiftSend = 0 or IsGiftSend IS NULL Then 'Hayır' else 'Evet' end as 'IsGiftSend',
(select IsGiftSend where IsGiftSend = 1) as GiftSendTrue,
Case when  IsSurveyComplated = 0 or IsSurveyComplated IS NULL Then 'Hayır' else 'Evet' end as 'IsSurveyComplated',
(select IsSurveyComplated where IsSurveyComplated = 1) as SurveyComplatedTrue,
Case when  KvkkForm = 0 or KvkkForm IS NULL Then 'Hayır' else 'Evet' end as 'KvkkForm',
Case when  Wset = 0 or Wset IS NULL Then 'Hayır' else 'Evet' end as 'Wset'
from Items i 
left join Associations a on a.FirstItemId = i.Id 
and a.AssociationTypeId = (select Id from AssociationTypes at2 where at2.Code = 'EVENT_CONTACT')
left join Associations a2 on a2.FirstItemId = i.Id 
and a2.AssociationTypeId = (select Id from AssociationTypes at2 where at2.Code = 'EVENT_SHARING')
left join Associations a3 on a3.SecondItemId = i.Id 
and a3.AssociationTypeId = (select Id from AssociationTypes at2 where at2.Code = 'EVENT_ROOFCARD')
left join ItemValues iv on iv.ItemId = i.Id 
and iv.AttributeId = (select id from Attributes where Code = 'DIA_Start_Date_E' )
left join ItemValues iv2 on iv2.ItemId = i.Id 
and iv2.AttributeId = (select id from Attributes where Code = 'DIA_Finish_Date_E' )
left join ItemValues iv3 on iv3.ItemId = i.Id 
and iv3.AttributeId = (select id from Attributes where Code = 'City_Roof' and ItemType = '70' )
left join ItemValues iv4 on iv4.ItemId = i.Id 
and iv4.AttributeId = (select id from Attributes where Code = 'DIA_Event_Type' )
left join ItemValues iv5 on iv5.ItemId = i.Id 
and iv5.AttributeId = (select id from Attributes where Code = 'Related_Product_Family' and ItemType = '70' )
left join ItemValues iv6 on iv6.ItemId = a.SecondItemId 
and iv6.AttributeId = (select id from Attributes where Code = 'Engagement_Type' )
left join ItemValues iv7 on iv7.ItemId = i.Id 
and iv7.AttributeId = (select id from Attributes where Code = 'DIA_Event_Name' )
left join ItemValues iv8 on iv8.ItemId = i.Id 
and iv8.AttributeId = (select id from Attributes where Code = 'Roof_Name' and ItemType = '70')
left join ItemValues iv9 on iv9.ItemId = a.SecondItemId 
and iv9.AttributeId = (select id from Attributes where Code = 'DIA_FirstName')
left join ItemValues iv10 on iv10.ItemId = a.SecondItemId 
and iv10.AttributeId = (select id from Attributes where Code = 'DIA_LastName')
left join ItemValues iv11 on iv11.ItemId = a.SecondItemId
and iv10.AttributeId = (select id from Attributes where Code = 'IYS_Mobile__c')
left join ItemValues iv12 on iv12.ItemId = a.SecondItemId
and iv10.AttributeId = (select id from Attributes where Code = 'DIA_Email')
left join ItemValues iv13 on iv13.ItemId = i.Id 
and iv13.AttributeId = (select id from Attributes where Code = 'DIA_Pricing' )
left join AttributeOptions ao on ao.Id = iv6.ValueInt 
Left Join AttributeOptionTranslations aot on aot.AttributeOptionId = ao.Id and aot.LanguageCode = 'tr-TR'
left join AttributeOptions ao1 on ao1.Id = iv5.ValueInt 
Left Join AttributeOptionTranslations aot1 on aot1.AttributeOptionId = ao1.Id and aot1.LanguageCode = 'tr-TR'
left join AttributeOptions ao2 on ao2.Id = iv4.ValueInt 
Left Join AttributeOptionTranslations aot2 on aot2.AttributeOptionId = ao2.Id and aot2.LanguageCode = 'tr-TR'
left join AttributeOptions ao3 on ao3.Id = iv3.ValueInt 
Left Join AttributeOptionTranslations aot3 on aot3.AttributeOptionId = ao3.Id and aot3.LanguageCode = 'tr-TR'
left join AssociationDatas ad on ad.AssociationId = a.Id where i.[Type] = 70;
go

