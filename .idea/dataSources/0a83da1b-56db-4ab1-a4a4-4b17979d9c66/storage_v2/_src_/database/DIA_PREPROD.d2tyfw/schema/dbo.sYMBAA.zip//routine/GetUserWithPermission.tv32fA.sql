CREATE PROCEDURE GetUserWithPermission @PermissionName NVARCHAR(255)
AS
BEGIN
    DECLARE @PermissionKey INT;

    SELECT @PermissionKey = [Key]
    FROM RolePermissions
    WHERE Name = @PermissionName;

    DECLARE @PermissionKeyString NVARCHAR(255) = CAST(@PermissionKey AS NVARCHAR(255));

    SELECT u.Id, u.FirstName + ' ' + u.LastName as FullName, r.Permissions
    FROM [User] u
    JOIN [AspNetUserRoles] ur ON ur.UserId = u.Id
    JOIN [AspNetRoles] r ON r.Id = ur.RoleId
    WHERE r.Permissions LIKE '%,' + @PermissionKeyString + ',%' 
        OR r.Permissions LIKE '[' + @PermissionKeyString + ',%' 
        OR r.Permissions LIKE '%,' + @PermissionKeyString + ']';
END


EXEC GetUserWithPermission @PermissionName = 'EditTask';
go

